package com.example.data.util

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestoreException

enum class OperationType {
    GET,
    LIST,
    CREATE,
    UPDATE,
    DELETE
}

fun handleFirestoreError(
    e: Exception,
    operation: OperationType,
    path: String
) {
    val firestoreException = e as? FirebaseFirestoreException
    val code = firestoreException?.code?.name ?: "UNKNOWN"
    val message = e.localizedMessage ?: "No message available"
    Log.e("FirestoreError", "[$operation] failed at '$path'. Code: $code, Message: $message", e)
}
