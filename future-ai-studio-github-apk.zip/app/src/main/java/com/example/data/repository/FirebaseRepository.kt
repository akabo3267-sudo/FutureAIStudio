package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.FeedbackRecord
import com.example.data.model.GeneratedImageRecord
import com.example.data.model.PaymentRequest
import com.example.data.model.PlanConfig
import com.example.data.model.PromptRecord
import com.example.data.model.Subscription
import com.example.data.model.UsageLimits
import com.example.data.model.UserProfile
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class FirebaseRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    fun getCurrentUserId(): String? = auth.currentUser?.uid

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("يجب تسجيل الدخول باستخدام حساب Google أولاً.")
    }

    private fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("Africa/Cairo")
        return sdf.format(Date())
    }

    // ----------------------------------------------------
    // User Profile
    // ----------------------------------------------------
    suspend fun getOrCreateUserProfile(email: String, fullName: String, avatarUrl: String): UserProfile {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val snapshot = docRef.get().await()

        if (snapshot.exists()) {
            val user = snapshot.toObject(UserProfile::class.java)
            if (user != null) {
                // If trial expires, check and update trialStatus
                val now = Timestamp.now().seconds
                val trialExpires = user.trialExpiresAt?.seconds ?: 0L
                if (user.role == "free" && user.trialStatus == "active" && trialExpires > 0 && now >= trialExpires) {
                    docRef.update(
                        mapOf(
                            "trialStatus" to "expired",
                            "subscriptionStatus" to "expired",
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                    return user.copy(trialStatus = "expired", subscriptionStatus = "expired")
                }
                return user
            }
        }

        // New User: 7 days free trial (168 hours)
        val nowSeconds = Timestamp.now().seconds
        val trialExpiresSeconds = nowSeconds + (7 * 24 * 3600) // 168 hours
        val isAdminEmail = email.equals("akabo3267@gmail.com", ignoreCase = true)
        val role = if (isAdminEmail) "admin" else "free"
        val subStatus = if (isAdminEmail) "active" else "trial"

        val newUser = UserProfile(
            uid = uid,
            email = email,
            fullName = fullName.ifBlank { "مستخدم جديد" },
            avatarUrl = avatarUrl,
            role = role,
            subscriptionPlan = if (isAdminEmail) "ADMIN UNLIMITED" else "FREE TRIAL",
            subscriptionStatus = subStatus,
            trialStartedAt = Timestamp(nowSeconds, 0),
            trialExpiresAt = Timestamp(trialExpiresSeconds, 0),
            trialStatus = "active"
        )

        val payload = mapOf(
            "uid" to uid,
            "email" to newUser.email,
            "fullName" to newUser.fullName,
            "avatarUrl" to newUser.avatarUrl,
            "role" to newUser.role,
            "subscriptionPlan" to newUser.subscriptionPlan,
            "subscriptionStatus" to newUser.subscriptionStatus,
            "trialStartedAt" to newUser.trialStartedAt,
            "trialExpiresAt" to newUser.trialExpiresAt,
            "trialStatus" to newUser.trialStatus,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        docRef.set(payload).await()

        // Initialize usage limits
        val limitsDoc = db.collection("usage_limits").document(uid)
        val limitsPayload = mapOf(
            "userId" to uid,
            "dailyPromptLimit" to if (isAdminEmail) 9999L else 1L,
            "dailyImageLimit" to if (isAdminEmail) 9999L else 0L,
            "usedPromptsToday" to 0L,
            "usedImagesToday" to 0L,
            "trialTotalPrompts" to 0L,
            "lastResetDate" to getTodayDateString(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        limitsDoc.set(limitsPayload).await()

        return newUser
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val docRef = db.collection("users").document(userId)
        emitAll(
            docRef.snapshots().map { snapshot ->
                snapshot.toObject(UserProfile::class.java)
            }
        )
    }

    suspend fun updateProfileInfo(fullName: String, avatarUrl: String) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        docRef.update(
            mapOf(
                "fullName" to fullName,
                "avatarUrl" to avatarUrl,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    // ----------------------------------------------------
    // Usage Limits & Verifications
    // ----------------------------------------------------
    fun observeUsageLimits(userId: String): Flow<UsageLimits?> = flow {
        val docRef = db.collection("usage_limits").document(userId)
        emitAll(
            docRef.snapshots().map { snapshot ->
                snapshot.toObject(UsageLimits::class.java)
            }
        )
    }

    suspend fun checkAndConsumePromptUsage(user: UserProfile): Pair<Boolean, String> {
        val uid = requireUserId()
        if (user.role == "admin") {
            return Pair(true, "صلاحيات الأدمن مفتوحة.")
        }

        val limitsRef = db.collection("usage_limits").document(uid)
        val todayStr = getTodayDateString()

        val snapshot = limitsRef.get().await()
        var limits = snapshot.toObject(UsageLimits::class.java) ?: UsageLimits(userId = uid)

        // Reset if new day
        var usedToday = limits.usedPromptsToday
        if (limits.lastResetDate != todayStr) {
            usedToday = 0L
        }

        if (user.role == "premium" && user.subscriptionStatus == "active") {
            if (usedToday >= limits.dailyPromptLimit) {
                return Pair(false, "لقد استهلكت حد البرومبتات اليومي المخصص لك (${limits.dailyPromptLimit}). يتجدد غداً.")
            }
        } else {
            // Free Trial
            if (!user.isTrialActive()) {
                return Pair(false, "انتهت فترة التجربة المجانية (7 أيام). يرجى الاشتراك في باقة Premium للمتابعة.")
            }
            if (limits.trialTotalPrompts >= 7L) {
                return Pair(false, "لقد استهلكت إجمالي البرومبتات المجانية المتاحة خلال فترة التجربة (7 برومبتات). اشترك الآن لتوليد غير محدود!")
            }
            if (usedToday >= 1L) {
                return Pair(false, "في التجربة المجانية، يُسمح ببرومبت واحد فقط كل 24 ساعة. يتجدد غداً بتوقيت مصر.")
            }
        }

        // Consume prompt
        limitsRef.update(
            mapOf(
                "usedPromptsToday" to usedToday + 1L,
                "trialTotalPrompts" to limits.trialTotalPrompts + 1L,
                "lastResetDate" to todayStr,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()

        return Pair(true, "تم التحقق واستهلاك البرومبت بنجاح.")
    }

    suspend fun checkAndConsumeImageUsage(user: UserProfile): Pair<Boolean, String> {
        val uid = requireUserId()
        if (user.role == "admin") {
            return Pair(true, "صلاحيات الأدمن مفتوحة.")
        }

        if (user.role != "premium" || user.subscriptionStatus != "active") {
            return Pair(false, "توليد الصور متاح فقط لمشتركي باقة PREMIUM. اشترك الآن بـ 750 ج.م للاستمتاع بالميزة!")
        }

        val limitsRef = db.collection("usage_limits").document(uid)
        val todayStr = getTodayDateString()
        val snapshot = limitsRef.get().await()
        val limits = snapshot.toObject(UsageLimits::class.java) ?: UsageLimits(userId = uid)

        var usedToday = limits.usedImagesToday
        if (limits.lastResetDate != todayStr) {
            usedToday = 0L
        }

        if (usedToday >= limits.dailyImageLimit) {
            return Pair(false, "لقد استهلكت حد توليد الصور اليومي (${limits.dailyImageLimit}). يتجدد غداً.")
        }

        limitsRef.update(
            mapOf(
                "usedImagesToday" to usedToday + 1L,
                "lastResetDate" to todayStr,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()

        return Pair(true, "تم استهلاك رصيد صورة بنجاح.")
    }

    // ----------------------------------------------------
    // Prompts and Images History
    // ----------------------------------------------------
    fun observePromptHistory(userId: String): Flow<List<PromptRecord>> = flow {
        val query = db.collection("prompt_history")
            .whereEqualTo("userId", userId)
            .orderBy("createdAt", Query.Direction.DESCENDING)

        emitAll(
            query.snapshots().map { snapshot ->
                snapshot.toObjects(PromptRecord::class.java)
            }
        )
    }

    suspend fun savePromptRecord(record: PromptRecord) {
        val uid = requireUserId()
        val docRef = db.collection("prompt_history").document()
        val payload = mapOf(
            "userId" to uid,
            "promptTitle" to record.promptTitle,
            "originalIdea" to record.originalIdea,
            "generatedPrompt" to record.generatedPrompt,
            "promptType" to record.promptType,
            "style" to record.style,
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    fun observeGeneratedImages(userId: String): Flow<List<GeneratedImageRecord>> = flow {
        val query = db.collection("generated_images")
            .whereEqualTo("userId", userId)
            .orderBy("createdAt", Query.Direction.DESCENDING)

        emitAll(
            query.snapshots().map { snapshot ->
                snapshot.toObjects(GeneratedImageRecord::class.java)
            }
        )
    }

    suspend fun saveGeneratedImage(record: GeneratedImageRecord) {
        val uid = requireUserId()
        val docRef = db.collection("generated_images").document()
        val payload = mapOf(
            "userId" to uid,
            "imageUrl" to record.imageUrl,
            "prompt" to record.prompt,
            "modelName" to record.modelName,
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    // ----------------------------------------------------
    // Payments & Subscriptions (Vodafone Cash)
    // ----------------------------------------------------
    fun observeUserPaymentRequests(userId: String): Flow<List<PaymentRequest>> = flow {
        val query = db.collection("payment_requests")
            .whereEqualTo("userId", userId)
            .orderBy("createdAt", Query.Direction.DESCENDING)

        emitAll(
            query.snapshots().map { snapshot ->
                snapshot.toObjects(PaymentRequest::class.java)
            }
        )
    }

    suspend fun submitPaymentRequest(
        transactionReference: String,
        receiptUrl: String,
        userEmail: String,
        userName: String
    ): PaymentRequest {
        val uid = requireUserId()

        // Check duplicate transactionReference
        val existing = db.collection("payment_requests")
            .whereEqualTo("transactionReference", transactionReference.trim())
            .get().await()

        if (!existing.isEmpty) {
            throw IllegalArgumentException("هذا الرقم المرجعي للمعاملة تم إرساله مسبقاً. يرجى التأكد من الرقم.")
        }

        val docRef = db.collection("payment_requests").document()
        val request = PaymentRequest(
            id = docRef.id,
            userId = uid,
            userEmail = userEmail,
            userName = userName,
            amount = 750.0,
            currency = "EGP",
            paymentMethod = "Vodafone Cash",
            walletNumber = "01035216387",
            transactionReference = transactionReference.trim(),
            receiptUrl = receiptUrl.trim(),
            status = "pending"
        )

        val payload = mapOf(
            "userId" to uid,
            "userEmail" to userEmail,
            "userName" to userName,
            "amount" to 750.0,
            "currency" to "EGP",
            "paymentMethod" to "Vodafone Cash",
            "walletNumber" to "01035216387",
            "transactionReference" to transactionReference.trim(),
            "receiptUrl" to receiptUrl.trim(),
            "status" to "pending",
            "adminNotes" to "",
            "createdAt" to FieldValue.serverTimestamp()
        )

        docRef.set(payload).await()
        return request
    }

    // ----------------------------------------------------
    // Admin Operations
    // ----------------------------------------------------
    fun observeAllUsers(): Flow<List<UserProfile>> = flow {
        emitAll(
            db.collection("users").snapshots().map { it.toObjects(UserProfile::class.java) }
        )
    }

    fun observeAllPaymentRequests(): Flow<List<PaymentRequest>> = flow {
        emitAll(
            db.collection("payment_requests")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .snapshots().map { it.toObjects(PaymentRequest::class.java) }
        )
    }

    fun observeAllSubscriptions(): Flow<List<Subscription>> = flow {
        emitAll(
            db.collection("subscriptions")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .snapshots().map { it.toObjects(Subscription::class.java) }
        )
    }

    suspend fun verifyAndActivateSubscription(
        paymentRequest: PaymentRequest,
        approve: Boolean,
        adminNotes: String
    ) {
        val payDoc = db.collection("payment_requests").document(paymentRequest.id)
        if (approve) {
            val nowSeconds = Timestamp.now().seconds
            val endSeconds = nowSeconds + (30L * 24 * 3600) // 30 days

            // 1. Update Payment Request
            payDoc.update(
                mapOf(
                    "status" to "verified",
                    "adminNotes" to adminNotes,
                    "verifiedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            // 2. Create Subscription Record
            val subDoc = db.collection("subscriptions").document()
            val subPayload = mapOf(
                "userId" to paymentRequest.userId,
                "planName" to "PREMIUM MONTHLY",
                "price" to paymentRequest.amount,
                "currency" to paymentRequest.currency,
                "status" to "active",
                "startDate" to Timestamp(nowSeconds, 0),
                "endDate" to Timestamp(endSeconds, 0),
                "paymentReference" to paymentRequest.transactionReference,
                "createdAt" to FieldValue.serverTimestamp()
            )
            subDoc.set(subPayload).await()

            // 3. Update User Document
            val userDoc = db.collection("users").document(paymentRequest.userId)
            userDoc.update(
                mapOf(
                    "role" to "premium",
                    "subscriptionPlan" to "PREMIUM MONTHLY",
                    "subscriptionStatus" to "active",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            // 4. Update Usage Limits for Premium
            val limitsDoc = db.collection("usage_limits").document(paymentRequest.userId)
            limitsDoc.update(
                mapOf(
                    "dailyPromptLimit" to 100L,
                    "dailyImageLimit" to 50L,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } else {
            payDoc.update(
                mapOf(
                    "status" to "rejected",
                    "adminNotes" to adminNotes,
                    "verifiedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }

    suspend fun updateUserRoleByAdmin(userId: String, newRole: String, status: String) {
        val userDoc = db.collection("users").document(userId)
        userDoc.update(
            mapOf(
                "role" to newRole,
                "subscriptionStatus" to status,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun sendFeedback(message: String, rating: Long) {
        val uid = requireUserId()
        val docRef = db.collection("feedback").document()
        val payload = mapOf(
            "userId" to uid,
            "userEmail" to (auth.currentUser?.email ?: ""),
            "message" to message,
            "rating" to rating,
            "createdAt" to FieldValue.serverTimestamp()
        )
        docRef.set(payload).await()
    }
}
