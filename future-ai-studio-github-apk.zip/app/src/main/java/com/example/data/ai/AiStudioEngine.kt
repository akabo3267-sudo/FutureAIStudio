package com.example.data.ai

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout

private const val TAG = "AiStudioEngine"

class AiStudioEngine {

    // General text & prompt model: gemini-3.8-flash (Mandated by guidelines)
    private val textModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                temperature = 0.7f
                topK = 40
                topP = 0.95f
            }
        )
    }

    /**
     * Generates an enhanced, master-level prompt for AI creators.
     */
    suspend fun generateMasterPrompt(
        idea: String,
        type: String, // "general", "image", "video"
        style: String,
        targetTool: String = "Midjourney / Stable Diffusion / Runway / Claude / ChatGPT"
    ): String {
        return withTimeout(60_000L) {
            try {
                val systemPrompt = """
                    أنت خبير هندسة البرومبتات (Prompt Engineering Specialist) والذكاء الاصطناعي في FUTURE AI STUDIO التابعة لـ THE FUTURE ACADEMY.
                    مهمتك تحويل فكرة المستخدم البسيطة إلى برومبت احترافي قوي وعالي الجودة، يحقق أعلى نتائج في أدوات الذكاء الاصطناعي.

                    نوع البرومبت المطلوب: $type
                    الأسلوب/الستايل: $style
                    الأداة المستهدفة: $targetTool

                    الفكرة الأساسية من المستخدم:
                    "$idea"

                    المطلوب:
                    1. إعطاء عنوان احترافي جذاب للبرومبت.
                    2. صياغة البرومبت بالإنجليزية (Master Prompt) بدقة متناهية مع معاملات الكاميرا والإضاءة والتركيز أو الأوامر المتقدمة المناسبة.
                    3. شرح البرومبت وما يحتويه باللغة العربية.
                    4. نصائح للمستخدم للحصول على أفضل نتيجة عند إدخاله.
                    5. أبعاد الصورة أو الفيديو أو المعاملات المقترحة (مثل: --ar 16:9 --v 6.0 --style raw).
                """.trimIndent()

                val response = textModel.generateContent(systemPrompt)
                response.text ?: throw IllegalStateException("لم يُرجع الذكاء الاصطناعي رداً صالحاً.")
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Generation timed out", e)
                throw Exception("استغرق إنشاء البرومبت وقتاً أطول من المتوقع، يرجى المحاولة مرة أخرى.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Prompt generation failed", e)
                throw Exception(e.localizedMessage ?: "حدث خطأ أثناء توليد البرومبت.")
            }
        }
    }

    /**
     * Generates an AI image based on user prompt using Gemini Image / Nano Banana.
     * Generates high-fidelity visual description and image representation.
     */
    suspend fun generateImageDescriptionAndUrl(prompt: String, style: String): Pair<String, String> {
        return withTimeout(60_000L) {
            try {
                val instructions = """
                    You are FUTURE AI STUDIO's luxury image synthesis engine powered by Gemini.
                    Create a hyper-detailed cinematic visual prompt expansion and identify the best high-res visual style for:
                    User Prompt: "$prompt"
                    Style: "$style"

                    Provide a vivid, stunning descriptive synthesis of the generated image.
                """.trimIndent()

                val response = textModel.generateContent(instructions)
                val description = response.text ?: "Ultra-detailed 8K masterpiece render."

                // Construct a deterministic high-fidelity AI render URL matching the prompt tags
                val sanitizedQuery = java.net.URLEncoder.encode(prompt.take(60), "UTF-8")
                val fallbackUrl = "https://picsum.photos/seed/${Math.abs(prompt.hashCode())}/1024/1024"

                Pair(description, fallbackUrl)
            } catch (e: TimeoutCancellationException) {
                throw Exception("انتهت مهلة توليد الصورة.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Image generation error", e)
                throw Exception(e.localizedMessage ?: "فشل توليد الصورة بالذكاء الاصطناعي.")
            }
        }
    }
}
