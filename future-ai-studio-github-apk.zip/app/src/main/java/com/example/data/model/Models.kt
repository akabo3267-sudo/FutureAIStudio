package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val email: String = "",
    val fullName: String = "",
    val avatarUrl: String = "",
    val role: String = "free", // "free", "premium", "admin"
    val subscriptionPlan: String = "none",
    val subscriptionStatus: String = "trial", // "trial", "active", "expired", "inactive"
    val trialStartedAt: Timestamp? = null,
    val trialExpiresAt: Timestamp? = null,
    val trialStatus: String = "active", // "active", "expired"
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun isTrialActive(): Boolean {
        if (role == "admin" || role == "premium") return false
        if (trialStatus == "expired") return false
        val expires = trialExpiresAt ?: return false
        return Timestamp.now().seconds < expires.seconds
    }

    fun isPremiumOrAdmin(): Boolean {
        return role == "admin" || (role == "premium" && subscriptionStatus == "active")
    }

    fun canUsePrompts(): Boolean {
        if (role == "admin") return true
        if (role == "premium" && subscriptionStatus == "active") return true
        return isTrialActive()
    }

    fun canGenerateImages(): Boolean {
        if (role == "admin") return true
        return role == "premium" && subscriptionStatus == "active"
    }
}

@IgnoreExtraProperties
data class Subscription(
    @DocumentId val id: String = "",
    val userId: String = "",
    val planName: String = "PREMIUM MONTHLY",
    val price: Double = 750.0,
    val currency: String = "EGP",
    val status: String = "active", // "active", "expired", "pending", "cancelled"
    val startDate: Timestamp? = null,
    val endDate: Timestamp? = null,
    val paymentReference: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PaymentRequest(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userEmail: String = "",
    val userName: String = "",
    val amount: Double = 750.0,
    val currency: String = "EGP",
    val paymentMethod: String = "Vodafone Cash",
    val walletNumber: String = "01035216387",
    val transactionReference: String = "",
    val receiptUrl: String = "",
    val status: String = "pending", // "pending", "verified", "rejected"
    val adminNotes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    val verifiedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PromptRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val promptTitle: String = "",
    val originalIdea: String = "",
    val generatedPrompt: String = "",
    val promptType: String = "general", // "general", "image", "video"
    val style: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class GeneratedImageRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val imageUrl: String = "",
    val prompt: String = "",
    val modelName: String = "gemini-nano-banana-2.1",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UsageLimits(
    @DocumentId val id: String = "",
    val userId: String = "",
    val dailyPromptLimit: Long = 1L,
    val dailyImageLimit: Long = 0L,
    val usedPromptsToday: Long = 0L,
    val usedImagesToday: Long = 0L,
    val trialTotalPrompts: Long = 0L,
    val lastResetDate: String = "", // e.g. "2026-11-07"
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PlanConfig(
    @DocumentId val id: String = "",
    val name: String = "PREMIUM MONTHLY",
    val description: String = "الباقة الشهرية المميزة الشاملة لجميع أدوات وتوليد الذكاء الاصطناعي",
    val price: Double = 750.0,
    val durationDays: Long = 30L,
    val features: List<String> = emptyList(),
    val dailyPromptLimit: Long = 100L,
    val dailyImageLimit: Long = 50L,
    val isActive: Boolean = true
)

@IgnoreExtraProperties
data class FeedbackRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userEmail: String = "",
    val message: String = "",
    val rating: Long = 5L,
    @ServerTimestamp val createdAt: Timestamp? = null
)
