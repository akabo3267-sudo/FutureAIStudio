package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.UsageLimits
import com.example.data.model.UserProfile
import com.example.data.repository.FirebaseRepository
import com.example.ui.theme.AcademyBlue
import com.example.ui.theme.CardBlack
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusOrange
import com.example.ui.theme.StatusRed
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.google.firebase.Timestamp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun UserDashboardScreen(
    userProfile: UserProfile?,
    usageLimits: UsageLimits?,
    repository: FirebaseRepository,
    onNavigateToSubscription: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showEditDialog by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf(userProfile?.fullName ?: "") }
    var avatarInput by remember { mutableStateOf(userProfile?.avatarUrl ?: "") }
    var isSavingProfile by remember { mutableStateOf(false) }

    var feedbackText by remember { mutableStateOf("") }
    var feedbackRating by remember { mutableIntStateOf(5) }
    var isSendingFeedback by remember { mutableStateOf(false) }

    val cairoSdf = SimpleDateFormat("dd MMM yyyy - hh:mm a", Locale("ar"))
    cairoSdf.timeZone = TimeZone.getTimeZone("Africa/Cairo")

    val trialExpiresFormatted = userProfile?.trialExpiresAt?.let {
        cairoSdf.format(Date(it.seconds * 1000))
    } ?: "غير محدد"

    val remainingTrialDays = userProfile?.trialExpiresAt?.let {
        val diffSeconds = it.seconds - Timestamp.now().seconds
        if (diffSeconds > 0) diffSeconds / (24 * 3600) else 0L
    } ?: 0L

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // User Profile Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardBlack),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!userProfile?.avatarUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = userProfile!!.avatarUrl,
                                contentDescription = "Avatar",
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .border(1.5.dp, GoldPrimary, CircleShape)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(AcademyBlue)
                                    .border(1.5.dp, GoldPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = GoldLight, modifier = Modifier.size(32.dp))
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = userProfile?.fullName?.ifBlank { "مستخدم المنصة" } ?: "مستخدم",
                                color = TextWhite,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = userProfile?.email ?: "",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            UserRoleBadge(role = userProfile?.role ?: "free", status = userProfile?.subscriptionStatus ?: "trial")
                        }

                        IconButton(
                            onClick = {
                                nameInput = userProfile?.fullName ?: ""
                                avatarInput = userProfile?.avatarUrl ?: ""
                                showEditDialog = true
                            }
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = GoldLight)
                        }
                    }

                    if (showEditDialog) {
                        Spacer(modifier = Modifier.height(14.dp))
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("الاسم الكامل") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = Color(0xFF2E3649)
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = avatarInput,
                            onValueChange = { avatarInput = it },
                            label = { Text("رابط الصورة الشخصية (اختياري)") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = Color(0xFF2E3649)
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    isSavingProfile = true
                                    scope.launch {
                                        try {
                                            repository.updateProfileInfo(nameInput, avatarInput)
                                            showEditDialog = false
                                            Toast.makeText(context, "تم تحديث الملف الشخصي بنجاح", Toast.LENGTH_SHORT).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "فشل التحديث: ${e.message}", Toast.LENGTH_SHORT).show()
                                        } finally {
                                            isSavingProfile = false
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                                enabled = !isSavingProfile
                            ) {
                                Text("حفظ التغييرات")
                            }
                            OutlinedButton(onClick = { showEditDialog = false }) {
                                Text("إلغاء", color = TextWhite)
                            }
                        }
                    }
                }
            }
        }

        // Subscription Status & Expiration Box
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF283042))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("تفاصيل وحالة الاشتراك:", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    if (userProfile?.role == "premium") {
                        InfoRow(label = "نوع الاشتراك:", value = "PREMIUM MONTHLY (نشط)")
                        InfoRow(label = "السعر:", value = "750 ج.م شهرياً")
                        InfoRow(label = "توليد الصور:", value = "مفعل ومتاح")
                    } else if (userProfile?.role == "admin") {
                        InfoRow(label = "نوع الاشتراك:", value = "مدير المنصة (ADMIN)")
                        InfoRow(label = "الصلاحيات:", value = "تحكم كامل وبلا حدود")
                    } else {
                        // Free Trial
                        InfoRow(label = "نوع الحساب:", value = "تجربة مجانية FREE TRIAL")
                        InfoRow(label = "الأيام المتبقية في التجربة:", value = "$remainingTrialDays يوم")
                        InfoRow(label = "تاريخ الانتهاء بتوقيت مصر:", value = trialExpiresFormatted)
                        InfoRow(label = "حالة التجربة:", value = if (userProfile?.isTrialActive() == true) "نشطة ومستمرة" else "منتهية (انتهت الـ 7 أيام)")
                        InfoRow(label = "توليد الصور:", value = "ممنوع (خاص بـ Premium)")
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onNavigateToSubscription,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("dashboard_subscribe_button")
                    ) {
                        Text(
                            text = if (userProfile?.role == "premium") "إدارة أو تجديد الاشتراك" else "الاشتراك في PREMIUM (750 ج.م)",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Usage Limits Overview
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardBlack),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242A38))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("عداد استهلاك العمليات اليومية:", color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        UsageStatCard(
                            title = "البرومبتات اليومية",
                            used = usageLimits?.usedPromptsToday ?: 0,
                            limit = if (userProfile?.role == "admin") 9999 else if (userProfile?.role == "premium") 100 else 1,
                            modifier = Modifier.weight(1f)
                        )

                        UsageStatCard(
                            title = "الصور اليومية",
                            used = usageLimits?.usedImagesToday ?: 0,
                            limit = if (userProfile?.role == "admin") 9999 else if (userProfile?.role == "premium") 50 else 0,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Send Feedback Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardBlack),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242A38))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Feedback, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ملاحظاتك وتقييمك للمنصة:", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = feedbackText,
                        onValueChange = { feedbackText = it },
                        placeholder = { Text("أخبرنا برأيك أو أي تحسينات تريدها في FUTURE AI STUDIO...") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = Color(0xFF2E3649)
                        ),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (feedbackText.isBlank()) return@Button
                            isSendingFeedback = true
                            scope.launch {
                                try {
                                    repository.sendFeedback(feedbackText, feedbackRating.toLong())
                                    feedbackText = ""
                                    Toast.makeText(context, "شكراً لك! تم إرسال تقييمك بنجاح.", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, "خطأ في الإرسال: ${e.message}", Toast.LENGTH_SHORT).show()
                                } finally {
                                    isSendingFeedback = false
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AcademyBlue, contentColor = GoldLight),
                        shape = RoundedCornerShape(8.dp),
                        enabled = !isSendingFeedback
                    ) {
                        Text("إرسال التقييم")
                    }
                }
            }
        }

        // Sign Out Button
        item {
            OutlinedButton(
                onClick = onSignOut,
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("sign_out_button"),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRed),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ExitToApp, contentDescription = null, tint = StatusRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تسجيل الخروج من الحساب", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun UserRoleBadge(role: String, status: String) {
    val (label, bg, fg) = when (role) {
        "admin" -> Triple("مدير المنصة (ADMIN)", Color(0xFF2E1538), GoldPrimary)
        "premium" -> Triple("مشترك PREMIUM", Color(0xFF13381B), StatusGreen)
        else -> Triple("مستخدم تجريبي (FREE)", Color(0xFF1A263D), GoldLight)
    }

    Box(
        modifier = Modifier
            .background(bg, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(text = label, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextMuted, fontSize = 12.sp)
        Text(text = value, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun UsageStatCard(title: String, used: Long, limit: Int, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, color = TextMuted, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (limit >= 9000) "$used / ∞" else "$used / $limit",
                color = GoldPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            val remaining = if (limit >= 9000) "غير محدود" else "${Math.max(0, limit - used)} متبقي"
            Text(remaining, color = GoldLight, fontSize = 10.sp)
        }
    }
}
