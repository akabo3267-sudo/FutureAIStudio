package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Luxury Dark Theme Colors with Royal Gold Accents
val DeepBlack = Color(0xFF090B0E)
val CardBlack = Color(0xFF13171F)
val SurfaceDark = Color(0xFF1A1F2B)
val BorderDark = Color(0xFF262C3D)

// Royal Gold Palette
val GoldLight = Color(0xFFFFE082)
val GoldPrimary = Color(0xFFFFC107)
val GoldDark = Color(0xFFFFB300)
val GoldAccent = Color(0xFFFFD54F)

// Deep Academy Blue
val AcademyBlue = Color(0xFF152A55)
val AcademyBlueLight = Color(0xFF1E3A78)
val AccentCyan = Color(0xFF00E5FF)

// Status colors
val StatusGreen = Color(0xFF00E676)
val StatusRed = Color(0xFFFF5252)
val StatusOrange = Color(0xFFFF9100)

val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFFB0B8C6)
val TextSecondary = Color(0xFF8A94A6)
