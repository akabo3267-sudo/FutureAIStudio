package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val LuxuryDarkColorScheme = darkColorScheme(
  primary = GoldPrimary,
  onPrimary = DeepBlack,
  primaryContainer = AcademyBlue,
  onPrimaryContainer = GoldLight,
  secondary = GoldAccent,
  onSecondary = DeepBlack,
  secondaryContainer = SurfaceDark,
  onSecondaryContainer = TextWhite,
  tertiary = AccentCyan,
  onTertiary = DeepBlack,
  background = DeepBlack,
  onBackground = TextWhite,
  surface = CardBlack,
  onSurface = TextWhite,
  surfaceVariant = SurfaceDark,
  onSurfaceVariant = TextMuted,
  outline = BorderDark,
  error = StatusRed,
  onError = TextWhite
)

@Composable
fun FutureAiStudioTheme(
  content: @Composable () -> Unit
) {
  // Brand identity: Luxury Dark & Gold aesthetic for THE FUTURE ACADEMY
  MaterialTheme(
    colorScheme = LuxuryDarkColorScheme,
    typography = Typography,
    content = content
  )
}
