package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentRequest
import com.example.data.model.UserProfile
import com.example.data.repository.FirebaseRepository
import com.example.ui.theme.AcademyBlue
import com.example.ui.theme.CardBlack
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusOrange
import com.example.ui.theme.StatusRed
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch

@Composable
fun SubscriptionScreen(
    userProfile: UserProfile?,
    repository: FirebaseRepository
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) }
    var transactionRefInput by remember { mutableStateOf("") }
    var receiptUrlInput by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }
    var paymentRequests by remember { mutableStateOf<List<PaymentRequest>>(emptyList()) }

    LaunchedEffect(userProfile?.uid) {
        userProfile?.uid?.let { uid ->
            repository.observeUserPaymentRequests(uid).collect { list ->
                paymentRequests = list
            }
        }
    }

    val walletNumber = "01035216387"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = CardBlack,
            contentColor = GoldPrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = GoldPrimary
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("باقة PREMIUM والدفع", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("طلبات الدفع (${paymentRequests.size})", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (selectedTab == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    // Plan Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CardBlack),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, GoldPrimary)
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("باقة PREMIUM MONTHLY", color = GoldPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text("المدة: 30 يوماً من تاريخ التفعيل", color = TextMuted, fontSize = 12.sp)
                                }
                                Text(
                                    text = "750 ج.م",
                                    color = GoldLight,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                FeatureItem("توليد الصور بالذكاء الاصطناعي بدقة فائقة")
                                FeatureItem("إنشاء برومبتات صور وفيديو متقدمة (Midjourney, Runway)")
                                FeatureItem("حدود استخدام يومية وشهرية مضاعفة (100 برومبت و50 صورة يومياً)")
                                FeatureItem("أولوية المعالجة بأسرع سيرفرات Gemini")
                                FeatureItem("سجل كامل غير محدود للأعمال والتوليدات")
                            }
                        }
                    }
                }

                item {
                    // Vodafone Cash Payment Instructions Box
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2B3346))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("طريقة الدفع عبر Vodafone Cash:", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text("1. قم بالتحويل إلى رقم محفظة فودافون كاش الرسمية:", color = TextWhite, fontSize = 12.sp)

                            Spacer(modifier = Modifier.height(8.dp))

                            // Wallet Number with Copy Button
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CardBlack),
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, GoldLight)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = walletNumber,
                                        color = GoldLight,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            clipboard.setPrimaryClip(ClipData.newPlainText("Vodafone Cash Wallet", walletNumber))
                                            Toast.makeText(context, "تم نسخ رقم المحفظة!", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = GoldPrimary)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("2. قيمة الاشتراك: 750 جنيه مصري بالضبط.", color = TextWhite, fontSize = 12.sp)
                            Text("3. احتفظ بالرقم المرجعي للمعاملة أو لقطة شاشة إيصال التحويل.", color = TextWhite, fontSize = 12.sp)
                            Text("4. أدخل الرقم المرجعي أدناه واضغط على (إرسال طلب الاشتراك).", color = TextWhite, fontSize = 12.sp)
                        }
                    }
                }

                item {
                    // Submission Form
                    Text("بيانات تأكيد التحويل:", color = GoldLight, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = transactionRefInput,
                        onValueChange = { transactionRefInput = it },
                        label = { Text("الرقم المرجعي للتحويل (Reference / Transaction ID) *") },
                        placeholder = { Text("مثال: 104928472910") },
                        modifier = Modifier.fillMaxWidth().testTag("transaction_reference_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = Color(0xFF2E3649),
                            focusedLabelColor = GoldPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = receiptUrlInput,
                        onValueChange = { receiptUrlInput = it },
                        label = { Text("رابط صورة الإيصال (اختياري)") },
                        placeholder = { Text("رابط إيصال التحويل إن وجد") },
                        modifier = Modifier.fillMaxWidth().testTag("receipt_url_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = Color(0xFF2E3649),
                            focusedLabelColor = GoldPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                if (errorMessage != null) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2A1215)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = errorMessage!!,
                                color = StatusRed,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }

                if (successMessage != null) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF112918)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = successMessage!!,
                                color = StatusGreen,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }

                item {
                    Button(
                        onClick = {
                            if (transactionRefInput.isBlank()) {
                                errorMessage = "يرجى إدخال الرقم المرجعي للمعاملة."
                                return@Button
                            }
                            if (userProfile == null) return@Button

                            isSubmitting = true
                            errorMessage = null
                            successMessage = null

                            scope.launch {
                                try {
                                    repository.submitPaymentRequest(
                                        transactionReference = transactionRefInput,
                                        receiptUrl = receiptUrlInput,
                                        userEmail = userProfile.email,
                                        userName = userProfile.fullName
                                    )
                                    successMessage = "تم إرسال طلب الاشتراك بنجاح! حالة الطلب الآن: قيد التحقق (سيتم مراجعته وتفعيل باقة Premium)."
                                    transactionRefInput = ""
                                    receiptUrlInput = ""
                                    Toast.makeText(context, "تم إرسال طلب الدفع بنجاح!", Toast.LENGTH_LONG).show()
                                } catch (e: Exception) {
                                    errorMessage = e.localizedMessage ?: "فشل إرسال طلب الدفع."
                                } finally {
                                    isSubmitting = false
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("submit_payment_request_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldPrimary,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(12.dp),
                        enabled = !isSubmitting
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = Color.Black,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("إرسال طلب الاشتراك والتحقق (750 ج.م)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            // Payment Requests List
            if (paymentRequests.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("لا توجد طلبات دفع مسجلة.", color = TextMuted, fontSize = 14.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(paymentRequests) { req ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CardBlack),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                when (req.status) {
                                    "verified" -> StatusGreen
                                    "rejected" -> StatusRed
                                    else -> StatusOrange
                                }
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${req.amount} ${req.currency} - ${req.paymentMethod}",
                                        color = GoldLight,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    PaymentStatusBadge(req.status)
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = "الرقم المرجعي: ${req.transactionReference}",
                                    color = TextWhite,
                                    fontSize = 12.sp
                                )

                                if (req.adminNotes.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "ملاحظات الإدارة: ${req.adminNotes}",
                                        color = GoldAccent,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentStatusBadge(status: String) {
    val (label, bgColor, textColor) = when (status) {
        "verified" -> Triple("تم التحقق وتفعيل Premium", Color(0xFF13381B), StatusGreen)
        "rejected" -> Triple("مرفوض", Color(0xFF381515), StatusRed)
        else -> Triple("قيد التحقق والمراجعة", Color(0xFF382913), StatusOrange)
    }

    Box(
        modifier = Modifier
            .background(bgColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text = label, color = textColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun FeatureItem(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(15.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = text, color = TextWhite, fontSize = 12.sp)
    }
}
