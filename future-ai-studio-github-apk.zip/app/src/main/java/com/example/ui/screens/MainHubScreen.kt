package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.ai.AiStudioEngine
import com.example.data.model.UsageLimits
import com.example.data.model.UserProfile
import com.example.data.repository.FirebaseRepository
import com.example.ui.theme.AcademyBlue
import com.example.ui.theme.CardBlack
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainHubScreen(
    currentUserId: String,
    repository: FirebaseRepository,
    aiEngine: AiStudioEngine,
    onSignOut: () -> Unit
) {
    val authUser = Firebase.auth.currentUser
    var userProfile by remember { mutableStateOf<UserProfile?>(null) }
    var usageLimits by remember { mutableStateOf<UsageLimits?>(null) }
    var currentTab by remember { mutableIntStateOf(0) }

    // Realtime listeners
    LaunchedEffect(currentUserId) {
        val email = authUser?.email ?: ""
        val name = authUser?.displayName ?: "مستخدم الأكاديمية"
        val photo = authUser?.photoUrl?.toString() ?: ""

        val profile = repository.getOrCreateUserProfile(email, name, photo)
        userProfile = profile

        // Listen for live user updates
        repository.observeUserProfile(currentUserId).collect { p ->
            if (p != null) userProfile = p
        }
    }

    LaunchedEffect(currentUserId) {
        repository.observeUsageLimits(currentUserId).collect { limits ->
            usageLimits = limits
        }
    }

    val isAdmin = userProfile?.role == "admin" || authUser?.email.equals("akabo3267@gmail.com", ignoreCase = true)

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.future_academy_logo),
                            contentDescription = "Future Academy Logo",
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .border(1.dp, GoldPrimary, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "FUTURE AI STUDIO",
                            color = GoldPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = CardBlack,
                    titleContentColor = GoldPrimary
                ),
                modifier = Modifier.statusBarsPadding()
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CardBlack,
                contentColor = GoldLight,
                modifier = Modifier.navigationBarsPadding()
            ) {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "البرومبتات") },
                    label = { Text("البرومبتات", fontSize = 11.sp, fontWeight = if (currentTab == 0) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepBlack,
                        selectedTextColor = GoldPrimary,
                        indicatorColor = GoldPrimary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )

                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    icon = { Icon(Icons.Default.Image, contentDescription = "توليد الصور") },
                    label = { Text("توليد الصور", fontSize = 11.sp, fontWeight = if (currentTab == 1) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepBlack,
                        selectedTextColor = GoldPrimary,
                        indicatorColor = GoldPrimary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )

                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    icon = { Icon(Icons.Default.Payment, contentDescription = "الاشتراكات") },
                    label = { Text("الاشتراك", fontSize = 11.sp, fontWeight = if (currentTab == 2) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepBlack,
                        selectedTextColor = GoldPrimary,
                        indicatorColor = GoldPrimary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )

                NavigationBarItem(
                    selected = currentTab == 3,
                    onClick = { currentTab = 3 },
                    icon = { Icon(Icons.Default.Person, contentDescription = "حسابي") },
                    label = { Text("حسابي", fontSize = 11.sp, fontWeight = if (currentTab == 3) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepBlack,
                        selectedTextColor = GoldPrimary,
                        indicatorColor = GoldPrimary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )

                if (isAdmin) {
                    NavigationBarItem(
                        selected = currentTab == 4,
                        onClick = { currentTab = 4 },
                        icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = "الإدارة") },
                        label = { Text("الإدارة", fontSize = 11.sp, fontWeight = if (currentTab == 4) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepBlack,
                            selectedTextColor = GoldPrimary,
                            indicatorColor = GoldPrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DeepBlack)
        ) {
            when (currentTab) {
                0 -> PromptStudioScreen(
                    userProfile = userProfile,
                    usageLimits = usageLimits,
                    repository = repository,
                    aiEngine = aiEngine,
                    onNavigateToSubscription = { currentTab = 2 }
                )
                1 -> ImageStudioScreen(
                    userProfile = userProfile,
                    usageLimits = usageLimits,
                    repository = repository,
                    aiEngine = aiEngine,
                    onNavigateToSubscription = { currentTab = 2 }
                )
                2 -> SubscriptionScreen(
                    userProfile = userProfile,
                    repository = repository
                )
                3 -> UserDashboardScreen(
                    userProfile = userProfile,
                    usageLimits = usageLimits,
                    repository = repository,
                    onNavigateToSubscription = { currentTab = 2 },
                    onSignOut = onSignOut
                )
                4 -> if (isAdmin) {
                    AdminControlPanelScreen(
                        userProfile = userProfile,
                        repository = repository
                    )
                }
            }
        }
    }
}
