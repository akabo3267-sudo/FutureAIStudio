package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentRequest
import com.example.data.model.Subscription
import com.example.data.model.UserProfile
import com.example.data.repository.FirebaseRepository
import com.example.ui.theme.AcademyBlue
import com.example.ui.theme.CardBlack
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusOrange
import com.example.ui.theme.StatusRed
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch

@Composable
fun AdminControlPanelScreen(
    userProfile: UserProfile?,
    repository: FirebaseRepository
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) }
    var userSearchQuery by remember { mutableStateOf("") }
    var allUsers by remember { mutableStateOf<List<UserProfile>>(emptyList()) }
    var allPayments by remember { mutableStateOf<List<PaymentRequest>>(emptyList()) }
    var allSubscriptions by remember { mutableStateOf<List<Subscription>>(emptyList()) }

    var adminNoteInput by remember { mutableStateOf("") }
    var processingPaymentId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        repository.observeAllUsers().collect { allUsers = it }
    }
    LaunchedEffect(Unit) {
        repository.observeAllPaymentRequests().collect { allPayments = it }
    }
    LaunchedEffect(Unit) {
        repository.observeAllSubscriptions().collect { allSubscriptions = it }
    }

    val totalUsers = allUsers.size
    val freeUsers = allUsers.count { it.role == "free" }
    val premiumUsers = allUsers.count { it.role == "premium" }
    val verifiedPayments = allPayments.filter { it.status == "verified" }
    val totalRevenue = verifiedPayments.sumOf { it.amount }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Admin Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBlack),
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Security, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("لوحة إدارة المنصة (ADMIN CONTROL PANEL)", color = GoldPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("إدارة الاشتراكات والمدفوعات والمستخدمين - THE FUTURE ACADEMY", color = TextMuted, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = CardBlack,
            contentColor = GoldPrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = GoldPrimary
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("الإحصائيات", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.BarChart, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("طلبات الدفع (${allPayments.count { it.status == "pending" }})", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("المستخدمين ($totalUsers)", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.Group, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        when (selectedTab) {
            0 -> {
                // Statistics
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AdminStatCard("إجمالي الإيرادات المؤكدة", "$totalRevenue ج.م", StatusGreen, Modifier.weight(1f))
                            AdminStatCard("مشتركي Premium", "$premiumUsers مشترك", GoldPrimary, Modifier.weight(1f))
                        }
                    }
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AdminStatCard("المستخدمين التجريبيين", "$freeUsers مستخدم", TextWhite, Modifier.weight(1f))
                            AdminStatCard("إجمالي الحسابات", "$totalUsers حساب", GoldLight, Modifier.weight(1f))
                        }
                    }
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CardBlack),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("إعدادات الباقة الحالية (PREMIUM MONTHLY):", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("• السعر: 750 جنيه مصري", color = TextWhite, fontSize = 12.sp)
                                Text("• المدة: 30 يوماً من تاريخ الموافقة الإدارية", color = TextWhite, fontSize = 12.sp)
                                Text("• محفظة فودافون كاش: 01035216387", color = TextWhite, fontSize = 12.sp)
                                Text("• حد البرومبتات اليومي: 100 برومبت", color = TextWhite, fontSize = 12.sp)
                                Text("• حد الصور اليومي: 50 صورة", color = TextWhite, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
            1 -> {
                // Payment requests approval
                if (allPayments.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("لا يوجد طلبات دفع حتى الآن.", color = TextMuted)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(allPayments) { pay ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = CardBlack),
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282F3E))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${pay.userName} (${pay.userEmail})",
                                            color = GoldLight,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        PaymentStatusBadge(pay.status)
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("المبلغ: ${pay.amount} ${pay.currency} - ${pay.paymentMethod}", color = TextWhite, fontSize = 12.sp)
                                    Text("الرقم المرجعي للمعاملة: ${pay.transactionReference}", color = GoldPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)

                                    if (pay.receiptUrl.isNotBlank()) {
                                        Text("رابط الإيصال: ${pay.receiptUrl}", color = TextMuted, fontSize = 11.sp)
                                    }

                                    if (pay.status == "pending") {
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Button(
                                                onClick = {
                                                    processingPaymentId = pay.id
                                                    scope.launch {
                                                        try {
                                                            repository.verifyAndActivateSubscription(
                                                                paymentRequest = pay,
                                                                approve = true,
                                                                adminNotes = "تم التحقق من استلام 750 ج.م على محفظة فودافون كاش وتفعيل باقة Premium بنجاح."
                                                            )
                                                            Toast.makeText(context, "تم تفعيل الاشتراك لمدة 30 يوماً بنجاح!", Toast.LENGTH_SHORT).show()
                                                        } catch (e: Exception) {
                                                            Toast.makeText(context, "خطأ: ${e.message}", Toast.LENGTH_SHORT).show()
                                                        } finally {
                                                            processingPaymentId = null
                                                        }
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = StatusGreen, contentColor = Color.Black),
                                                modifier = Modifier.weight(1f),
                                                enabled = processingPaymentId != pay.id
                                            ) {
                                                Text("قبول وتفعيل Premium", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }

                                            Button(
                                                onClick = {
                                                    processingPaymentId = pay.id
                                                    scope.launch {
                                                        try {
                                                            repository.verifyAndActivateSubscription(
                                                                paymentRequest = pay,
                                                                approve = false,
                                                                adminNotes = "تم رفض الطلب: لم يتم العثور على المعاملة بالقيمة الصحيحة."
                                                            )
                                                            Toast.makeText(context, "تم رفض الطلب", Toast.LENGTH_SHORT).show()
                                                        } catch (e: Exception) {
                                                            Toast.makeText(context, "خطأ: ${e.message}", Toast.LENGTH_SHORT).show()
                                                        } finally {
                                                            processingPaymentId = null
                                                        }
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = StatusRed, contentColor = TextWhite),
                                                modifier = Modifier.weight(0.7f),
                                                enabled = processingPaymentId != pay.id
                                            ) {
                                                Text("رفض", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                // User management
                Column(modifier = Modifier.fillMaxSize()) {
                    OutlinedTextField(
                        value = userSearchQuery,
                        onValueChange = { userSearchQuery = it },
                        label = { Text("بحث عن مستخدم بالاسم أو البريد") },
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = GoldLight) },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GoldPrimary)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val filteredUsers = allUsers.filter {
                        it.email.contains(userSearchQuery, ignoreCase = true) ||
                        it.fullName.contains(userSearchQuery, ignoreCase = true)
                    }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredUsers) { u ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = CardBlack),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(u.fullName.ifBlank { "مستخدم" }, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(u.email, color = TextMuted, fontSize = 11.sp)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        UserRoleBadge(u.role, u.subscriptionStatus)
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        if (u.role != "premium") {
                                            Button(
                                                onClick = {
                                                    scope.launch {
                                                        repository.updateUserRoleByAdmin(u.uid, "premium", "active")
                                                        Toast.makeText(context, "تمت الترقية إلى Premium", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
                                                modifier = Modifier.height(32.dp)
                                            ) {
                                                Text("ترقية", fontSize = 10.sp)
                                            }
                                        } else {
                                            Button(
                                                onClick = {
                                                    scope.launch {
                                                        repository.updateUserRoleByAdmin(u.uid, "free", "expired")
                                                        Toast.makeText(context, "تم التحويل إلى Free", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark, contentColor = TextMuted),
                                                modifier = Modifier.height(32.dp)
                                            ) {
                                                Text("إنهاء", fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CardBlack),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF272F41))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, color = TextMuted, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = color, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}
