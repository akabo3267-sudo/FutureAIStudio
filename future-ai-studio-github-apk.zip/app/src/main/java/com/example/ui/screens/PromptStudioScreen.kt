package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ai.AiStudioEngine
import com.example.data.model.PromptRecord
import com.example.data.model.UsageLimits
import com.example.data.model.UserProfile
import com.example.data.repository.FirebaseRepository
import com.example.ui.theme.AcademyBlue
import com.example.ui.theme.CardBlack
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromptStudioScreen(
    userProfile: UserProfile?,
    usageLimits: UsageLimits?,
    repository: FirebaseRepository,
    aiEngine: AiStudioEngine,
    onNavigateToSubscription: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: توليد برومبت, 1: السجل
    var promptType by remember { mutableStateOf("general") } // general, image, video
    var selectedStyle by remember { mutableStateOf("سينمائي واقعي (Photorealistic)") }
    var ideaInput by remember { mutableStateOf("") }
    var titleInput by remember { mutableStateOf("") }

    var isGenerating by remember { mutableStateOf(false) }
    var generatedResult by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var historyList by remember { mutableStateOf<List<PromptRecord>>(emptyList()) }

    // Observe prompt history
    androidx.compose.runtime.LaunchedEffect(userProfile?.uid) {
        userProfile?.uid?.let { uid ->
            repository.observePromptHistory(uid).collect { list ->
                historyList = list
            }
        }
    }

    val styles = listOf(
        "سينمائي واقعي (Photorealistic)",
        "خيال علمي وسريالي (Sci-Fi / Cyberpunk)",
        "فن رقمي 3D (Octane Render / Unreal 5)",
        "أنمي واستوديو جيبلي (Anime / Studio Ghibli)",
        "تصميم إعلاني تجاري (Commercial Product)"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Usage Bar
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (userProfile?.role == "premium") "حساب PREMIUM مشترك"
                        else if (userProfile?.role == "admin") "حساب ADMIN"
                        else "تجربة مجانية (7 أيام)",
                        color = GoldPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (userProfile?.role == "premium") "البرومبتات اليومية: ${usageLimits?.usedPromptsToday ?: 0} / ${usageLimits?.dailyPromptLimit ?: 100}"
                        else if (userProfile?.role == "admin") "البرومبتات: غير محدودة"
                        else "المتبقي اليوم: ${if ((usageLimits?.usedPromptsToday ?: 0) >= 1) 0 else 1} برومبت (الإجمالي المستخدم: ${usageLimits?.trialTotalPrompts ?: 0}/7)",
                        color = TextWhite,
                        fontSize = 11.sp
                    )
                }

                if (userProfile?.role != "premium" && userProfile?.role != "admin") {
                    Button(
                        onClick = onNavigateToSubscription,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldPrimary,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text("ترقية لـ Premium", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = CardBlack,
            contentColor = GoldPrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = GoldPrimary
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("مهندس البرومبتات الذكي", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("سجل البرومبتات (${historyList.size})", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (selectedTab == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    // Type selector
                    Text("اختر نوع البرومبت المطلوب:", color = GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = promptType == "general",
                            onClick = { promptType = "general" },
                            label = { Text("نصوص وأفكار", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GoldPrimary,
                                selectedLabelColor = Color.Black
                            )
                        )
                        FilterChip(
                            selected = promptType == "image",
                            onClick = { promptType = "image" },
                            label = { Text("برومبت صور (Midjourney/SD)", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GoldPrimary,
                                selectedLabelColor = Color.Black
                            )
                        )
                        FilterChip(
                            selected = promptType == "video",
                            onClick = { promptType = "video" },
                            label = { Text("برومبت فيديو (Runway/Sora)", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GoldPrimary,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }

                item {
                    // Title input
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text("عنوان أو موضوع البرومبت") },
                        placeholder = { Text("مثال: إعلان ساعة فاخرة، شخصية محارب مستقبلي...") },
                        modifier = Modifier.fillMaxWidth().testTag("prompt_title_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = Color(0xFF2E3649),
                            focusedLabelColor = GoldPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                item {
                    // Idea input
                    OutlinedTextField(
                        value = ideaInput,
                        onValueChange = { ideaInput = it },
                        label = { Text("صف فكرتك بالتفصيل (عربي أو إنجليزي)") },
                        placeholder = { Text("اكتب فكرتك الأساسية وسيقوم FUTURE AI STUDIO بتحويلها إلى برومبت احترافي متكامل...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .testTag("prompt_idea_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = Color(0xFF2E3649),
                            focusedLabelColor = GoldPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        maxLines = 6
                    )
                }

                item {
                    // Style selection
                    Text("الأسلوب والنمط (Style):", color = GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        styles.forEach { st ->
                            FilterChip(
                                selected = selectedStyle == st,
                                onClick = { selectedStyle = st },
                                label = { Text(st, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldAccent,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }
                }

                if (errorMessage != null) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2A1215)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = errorMessage!!,
                                color = StatusRed,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }

                item {
                    // Action button
                    Button(
                        onClick = {
                            if (ideaInput.isBlank()) {
                                errorMessage = "يرجى كتابة فكرة البرومبت أولاً."
                                return@Button
                            }
                            if (userProfile == null) return@Button

                            isGenerating = true
                            errorMessage = null

                            scope.launch {
                                try {
                                    // Usage limit check
                                    val (canProceed, msg) = repository.checkAndConsumePromptUsage(userProfile)
                                    if (!canProceed) {
                                        errorMessage = msg
                                        isGenerating = false
                                        return@launch
                                    }

                                    val generated = aiEngine.generateMasterPrompt(
                                        idea = ideaInput,
                                        type = promptType,
                                        style = selectedStyle
                                    )
                                    generatedResult = generated

                                    // Save to Firestore history
                                    val title = titleInput.ifBlank { ideaInput.take(30) + "..." }
                                    repository.savePromptRecord(
                                        PromptRecord(
                                            userId = userProfile.uid,
                                            promptTitle = title,
                                            originalIdea = ideaInput,
                                            generatedPrompt = generated,
                                            promptType = promptType,
                                            style = selectedStyle
                                        )
                                    )
                                    Toast.makeText(context, "تم توليد وحفظ البرومبت بنجاح!", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    errorMessage = e.localizedMessage ?: "حدث خطأ أثناء التوليد"
                                } finally {
                                    isGenerating = false
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("generate_prompt_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldPrimary,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(12.dp),
                        enabled = !isGenerating
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = Color.Black,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري الصياغة بواسطة Gemini...", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("توليد البرومبت الاحترافي الآن", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Result Box
                if (generatedResult != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CardBlack),
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("نتيجة البرومبت الاحترافي:", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            clipboard.setPrimaryClip(ClipData.newPlainText("Prompt", generatedResult))
                                            Toast.makeText(context, "تم نسخ البرومبت بنجاح!", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = GoldLight)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                SelectionContainer {
                                    Text(
                                        text = generatedResult!!,
                                        color = TextWhite,
                                        fontSize = 13.sp,
                                        lineHeight = 20.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // History list
            if (historyList.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("لا يوجد برومبتات محفوظة حتى الآن.", color = TextMuted, fontSize = 14.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(historyList) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CardBlack),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282F3E))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.promptTitle,
                                        color = GoldLight,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            clipboard.setPrimaryClip(ClipData.newPlainText("Prompt", item.generatedPrompt))
                                            Toast.makeText(context, "تم نسخ البرومبت!", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = GoldPrimary, modifier = Modifier.size(18.dp))
                                    }
                                }

                                Text(
                                    text = "النوع: ${item.promptType} | النمط: ${item.style}",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = item.generatedPrompt,
                                    color = TextWhite,
                                    fontSize = 12.sp,
                                    maxLines = 4
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
