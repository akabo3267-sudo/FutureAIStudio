package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import com.example.data.ai.AiStudioEngine
import com.example.data.repository.FirebaseRepository
import com.example.data.util.configureAppCheck
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.MainHubScreen
import com.example.ui.screens.signOutUser
import com.example.ui.theme.FutureAiStudioTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    // App Check wiring in onCreate with intent before any UI or Firebase operations
    configureAppCheck(this, intent)

    enableEdgeToEdge()

    val repository = FirebaseRepository(this)
    val aiEngine = AiStudioEngine()

    setContent {
      FutureAiStudioTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
          AppNavigationRoot(repository, aiEngine)
        }
      }
    }
  }
}

@Composable
fun AppNavigationRoot(
  repository: FirebaseRepository,
  aiEngine: AiStudioEngine
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember { CredentialManager.create(context) }
  var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

  DisposableEffect(Unit) {
    val listener = FirebaseAuth.AuthStateListener { auth ->
      currentUser = auth.currentUser
    }
    Firebase.auth.addAuthStateListener(listener)
    onDispose {
      Firebase.auth.removeAuthStateListener(listener)
    }
  }

  if (currentUser == null) {
    AuthScreen(
      onAuthSuccess = {
        currentUser = Firebase.auth.currentUser
      }
    )
  } else {
    val uid = currentUser!!.uid
    key(uid) {
      MainHubScreen(
        currentUserId = uid,
        repository = repository,
        aiEngine = aiEngine,
        onSignOut = {
          signOutUser(credentialManager, scope) {
            currentUser = null
          }
        }
      )
    }
  }
}
