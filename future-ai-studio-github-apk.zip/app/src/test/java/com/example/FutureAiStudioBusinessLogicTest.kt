package com.example

import com.example.data.model.UserProfile
import com.google.firebase.Timestamp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FutureAiStudioBusinessLogicTest {

    @Test
    fun testFreeTrialActiveWithin7Days() {
        val now = Timestamp.now().seconds
        val user = UserProfile(
            uid = "user123",
            role = "free",
            subscriptionStatus = "trial",
            trialStartedAt = Timestamp(now, 0),
            trialExpiresAt = Timestamp(now + 168 * 3600, 0),
            trialStatus = "active"
        )

        assertTrue(user.isTrialActive())
        assertTrue(user.canUsePrompts())
        assertFalse("Free user must not generate images", user.canGenerateImages())
    }

    @Test
    fun testFreeTrialExpiredAfter7Days() {
        val now = Timestamp.now().seconds
        val expiredUser = UserProfile(
            uid = "user123",
            role = "free",
            subscriptionStatus = "expired",
            trialStartedAt = Timestamp(now - 200 * 3600, 0),
            trialExpiresAt = Timestamp(now - 32 * 3600, 0),
            trialStatus = "expired"
        )

        assertFalse(expiredUser.isTrialActive())
        assertFalse("Expired free user cannot use prompts", expiredUser.canUsePrompts())
        assertFalse(expiredUser.canGenerateImages())
    }

    @Test
    fun testPremiumUserPermissions() {
        val premiumUser = UserProfile(
            uid = "prem123",
            role = "premium",
            subscriptionPlan = "PREMIUM MONTHLY",
            subscriptionStatus = "active"
        )

        assertTrue(premiumUser.isPremiumOrAdmin())
        assertTrue(premiumUser.canUsePrompts())
        assertTrue("Premium user can generate images", premiumUser.canGenerateImages())
    }

    @Test
    fun testAdminUserPermissions() {
        val adminUser = UserProfile(
            uid = "admin123",
            role = "admin",
            subscriptionStatus = "active"
        )

        assertTrue(adminUser.isPremiumOrAdmin())
        assertTrue(adminUser.canUsePrompts())
        assertTrue(adminUser.canGenerateImages())
    }
}
